
'use client';

import React from 'react';
import { useRouter } from 'next/navigation';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { SensitiveActionReauthDialog } from '@/components/auth/sensitive-action-reauth-dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';
import { ArrowLeft } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import Link from 'next/link';
import { userManagementSchema, type UserManagementValues } from '@/lib/schemas';
import { HoverTooltip } from '@/components/ui/hover-tooltip';
import { useData } from '@/context/data-context';
import { getClientAuth } from '@/lib/firebase/auth-client';
import { isLiveMode } from '@/lib/config/app-mode';
import { useRuntimeCapabilities } from '@/hooks/use-runtime-capabilities';

function formatListInput(value: string[]) {
  return value.join(', ');
}

function parseListInput(value: string) {
  return value
    .split(/[\n,]/)
    .map((item) => item.trim())
    .filter(Boolean);
}

export default function AddUserPage() {
  const router = useRouter();
  const { toast } = useToast();
  const { addUser, users } = useData();
  const { capabilities } = useRuntimeCapabilities();
  const [isSubmitting, setIsSubmitting] = React.useState(false);
  const [showStepUpDialog, setShowStepUpDialog] = React.useState(false);
  const [pendingSubmission, setPendingSubmission] = React.useState<UserManagementValues | null>(null);

  const form = useForm<UserManagementValues>({
    resolver: zodResolver(userManagementSchema),
    defaultValues: {
      name: '',
      email: '',
      title: '',
      phone: '',
      role: 'barangay',
      status: 'pending_setup',
      preferredWorkspace: 'simple',
      assignmentRole: 'owner',
      availabilityStatus: 'available',
      shiftStartTime: '',
      shiftEndTime: '',
      assignedZones: [],
      expertiseTags: [],
      availabilityNote: '',
    },
  });

  const submitAddUser = async (data: UserManagementValues) => {
    if (users.some(u => u.email === data.email)) {
      form.setError('email', {
        type: 'manual',
        message: 'Ang email na ito ay ginagamit na.',
      });
      return;
    }

    setIsSubmitting(true);

    try {
      if (isLiveMode) {
        const idToken = await getClientAuth().currentUser?.getIdToken();

        if (!idToken) {
          throw new Error('Walang authenticated developer session.');
        }

        const response = await fetch('/api/developer/users', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${idToken}`,
          },
          body: JSON.stringify(data),
        });
        const payload = await response.json().catch(() => ({}));

        if (!response.ok) {
          if (payload.code === 'step_up_required') {
            setPendingSubmission(data);
            setShowStepUpDialog(true);
            return;
          }
          throw new Error(payload.error ?? 'Hindi nagawa ang live user provisioning.');
        }

        if (payload.setupLink && typeof navigator !== 'undefined' && navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(payload.setupLink);
        }

        toast({
          title: 'Tagumpay!',
          description:
            payload.inviteDeliveryStatus === 'emailed'
              ? `Nagawa ang live account ni ${data.name}, at naipadala na ang secure setup email.`
              : payload.statusAdjusted
                ? `Nagawa ang account ni ${data.name} bilang pending setup muna. Maa-activate ito kapag nakumpleto ang onboarding checklist ng user.`
              : payload.setupLink
                ? `Nagawa ang live account ni ${data.name}. Nakopya na sa clipboard ang secure setup link bilang manual fallback.`
                : `Nagawa ang live account ni ${data.name}.`,
        });
      } else {
        addUser(data);
        toast({
          title: 'Tagumpay!',
          description: `Naidagdag na ang live user profile ni ${data.name}. Hintayin ang account setup para maging active ito.`,
        });
      }

      router.push('/dashboard/developer');
    } catch (error) {
      toast({
        title: 'Hindi maidagdag ang user',
        description: error instanceof Error ? error.message : 'Hindi nagawa ang live user provisioning.',
        variant: 'destructive',
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleAddUser = async (data: UserManagementValues) => {
    await submitAddUser(data);
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4">
        <HoverTooltip text="Bumalik sa Developer Dashboard">
            <Button variant="outline" size="icon" asChild>
            <Link href="/dashboard/developer">
                <ArrowLeft />
            </Link>
            </Button>
        </HoverTooltip>
        <div className="space-y-1">
          <h1 className="text-2xl font-bold tracking-tight">Magdagdag ng Bagong User</h1>
          <p className="text-muted-foreground">Punan ang mga detalye ng bagong barangay staff user.</p>
        </div>
      </div>

      <Card>
        <CardHeader>
            <CardTitle>Form ng Pagpaparehistro ng User</CardTitle>
            <CardDescription>
              Punan ang mga detalye sa ibaba. Ang form na ito ay para sa barangay staff accounts lamang.
              {capabilities.inviteEmailConfigured
                ? ' Awtomatikong magpapadala ang system ng secure setup email sa bagong user.'
                : ' Kung wala pang configured invite email provider, secure setup link ang ibibigay bilang manual fallback sa halip na pansamantalang password.'}
            </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(handleAddUser)} className="max-w-2xl space-y-6">
              <div className="rounded-xl border border-primary/15 bg-primary/5 p-4 text-sm text-muted-foreground">
                <p className="font-medium text-foreground">Provisioning mode</p>
                <p className="mt-1">
                  {capabilities.inviteEmailConfigured
                    ? 'Automatic invite email ang gamit ngayon. Kapag naisave ang user, makakatanggap agad siya ng secure setup email.'
                    : capabilities.reasons.inviteEmail ?? 'Naka-manual secure-link fallback pa ang provisioning habang wala pang configured invite email delivery.'}
                </p>
              </div>
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Buong Pangalan</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Juan dela Cruz" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email Address</FormLabel>
                    <FormControl>
                      <Input type="email" {...field} placeholder="juan@example.com" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Tungkulin</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="Hal. Agricultural Extension Worker" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Mobile Number</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="+63917..." />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="rounded-xl border border-primary/15 bg-primary/5 p-4 text-sm text-muted-foreground">
                <p className="font-medium text-foreground">Barangay Staff Access</p>
                <p className="mt-1">
                  Ang accounts na ginagawa sa form na ito ay para sa barangay operations lamang. Ang developer access ay pinamamahalaan sa hiwalay na secure provisioning flow.
                </p>
              </div>
              <div className="grid gap-6 md:grid-cols-2">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="pending_setup">Pending Setup</SelectItem>
                          <SelectItem value="disabled">Disabled</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="assignmentRole"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Assignment Role</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="recipient">Recipient / First Touch</SelectItem>
                          <SelectItem value="owner">Case Owner</SelectItem>
                          <SelectItem value="resolver">Resolving Officer</SelectItem>
                          <SelectItem value="supervisor">Supervisor / Escalation</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="availabilityStatus"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Availability Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="busy">Busy / Limited</SelectItem>
                          <SelectItem value="off_shift">Off Shift</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="preferredWorkspace"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Workspace sa Login</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="simple">Simple Workspace</SelectItem>
                          <SelectItem value="detailed">Detailed Workspace</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <div className="rounded-xl border border-border/70 bg-muted/20 p-4">
                <div className="space-y-1">
                  <p className="text-sm font-medium text-foreground">Routing and field coverage</p>
                  <p className="text-sm text-muted-foreground">
                    Ang impormasyong ito ang gagamitin ng assignment engine para malaman kung sino ang pinakaangkop sa urgent cases, field visits, at zone coverage.
                  </p>
                </div>
                <div className="mt-4 grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="shiftStartTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shift Start</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} value={field.value ?? ''} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="shiftEndTime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Shift End</FormLabel>
                        <FormControl>
                          <Input type="time" {...field} value={field.value ?? ''} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="assignedZones"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <FormLabel>Assigned Zones</FormLabel>
                        <FormControl>
                          <Input
                            value={formatListInput(field.value)}
                            onChange={(event) => field.onChange(parseListInput(event.target.value))}
                            placeholder="Zone 1, Zone 2, Zone 3"
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">Comma-separated. Gamitin ito kapag may primary coverage area ang staff.</p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="expertiseTags"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <FormLabel>Expertise Tags</FormLabel>
                        <FormControl>
                          <Input
                            value={formatListInput(field.value)}
                            onChange={(event) => field.onChange(parseListInput(event.target.value))}
                            placeholder="pest, weather, field, crop, coordination"
                          />
                        </FormControl>
                        <p className="text-xs text-muted-foreground">Halimbawa: pest, weather, field, crop, records, escalation.</p>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="availabilityNote"
                    render={({ field }) => (
                      <FormItem className="md:col-span-2">
                        <FormLabel>Availability Note</FormLabel>
                        <FormControl>
                          <Textarea
                            {...field}
                            value={field.value ?? ''}
                            placeholder="Hal. Nasa field tuwing umaga; tawagan muna bago i-assign sa after-hours visit."
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>
              <div className="flex justify-end pt-4">
                <Button type="submit" disabled={isSubmitting}>
                  {isSubmitting ? 'Nagse-save...' : 'I-save ang User'}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>

      <SensitiveActionReauthDialog
        open={showStepUpDialog}
        onOpenChange={setShowStepUpDialog}
        title="Kumpirmahin ang password bago mag-provision"
        description="Sensitive ang staff provisioning, kaya kailangan muna ng fresh password verification bago gumawa o magpadala ng bagong invite."
        submitLabel="I-verify at ipagpatuloy"
        onVerified={async () => {
          if (pendingSubmission) {
            const nextSubmission = pendingSubmission;
            setPendingSubmission(null);
            await submitAddUser(nextSubmission);
          }
        }}
      />
    </div>
  );
}
