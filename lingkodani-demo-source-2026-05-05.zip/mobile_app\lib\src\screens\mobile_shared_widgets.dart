import 'package:flutter/material.dart';

import '../core/models/mobile_models.dart';

class MobileMetricCard extends StatelessWidget {
  const MobileMetricCard({
    super.key,
    required this.label,
    required this.value,
    required this.icon,
  });

  final String label;
  final String value;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 160,
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, color: const Color(0xFF2F7A3E)),
              const SizedBox(height: 16),
              Text(
                value,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(color: Colors.grey.shade600)),
            ],
          ),
        ),
      ),
    );
  }
}

class MobileStatusChip extends StatelessWidget {
  const MobileStatusChip({super.key, required this.text, required this.color});

  final String text;
  final MaterialColor color;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.shade50,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.shade200),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color.shade800,
          fontSize: 12,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class MobileInfoChip extends StatelessWidget {
  const MobileInfoChip({super.key, required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: const Color(0xFFF3F4F6),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600),
      ),
    );
  }
}

class MobileEmptyCard extends StatelessWidget {
  const MobileEmptyCard({super.key, required this.message});

  final String message;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Text(message, style: TextStyle(color: Colors.grey.shade700)),
      ),
    );
  }
}

class MobileErrorState extends StatelessWidget {
  const MobileErrorState({
    super.key,
    required this.message,
    required this.onRetry,
  });

  final String message;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.error_outline_rounded, size: 40),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 12),
            OutlinedButton(
              onPressed: onRetry,
              child: const Text('Subukan muli'),
            ),
          ],
        ),
      ),
    );
  }
}

class MobileSyncWatchCard extends StatelessWidget {
  const MobileSyncWatchCard({
    super.key,
    required this.pendingCount,
    required this.retryNeededCount,
    required this.manualReviewCount,
    required this.longPendingCount,
    required this.syncing,
    required this.dataMayBeStale,
    required this.lastSyncLabel,
    this.errorMessage,
  });

  final int pendingCount;
  final int retryNeededCount;
  final int manualReviewCount;
  final int longPendingCount;
  final bool syncing;
  final bool dataMayBeStale;
  final String lastSyncLabel;
  final String? errorMessage;

  @override
  Widget build(BuildContext context) {
    final hasAttention =
        retryNeededCount > 0 || manualReviewCount > 0 || longPendingCount > 0;
    final backgroundColor = hasAttention
        ? const Color(0xFFFEF2F2)
        : dataMayBeStale
        ? const Color(0xFFFFFBEB)
        : const Color(0xFFF0FDF4);
    final borderColor = hasAttention
        ? const Color(0xFFFCA5A5)
        : dataMayBeStale
        ? const Color(0xFFFDE68A)
        : const Color(0xFF86EFAC);
    final iconColor = hasAttention
        ? const Color(0xFFB91C1C)
        : dataMayBeStale
        ? const Color(0xFFB45309)
        : const Color(0xFF166534);
    final title = syncing
        ? 'Nagsi-sync ang mobile queue'
        : hasAttention
        ? 'May mobile actions na kailangang bantayan'
        : dataMayBeStale
        ? 'Maaaring luma na ang ilang datos'
        : 'Maayos ang huling mobile sync';

    return Card(
      color: backgroundColor,
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: borderColor),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(
                  syncing
                      ? Icons.sync_rounded
                      : hasAttention
                      ? Icons.warning_amber_rounded
                      : dataMayBeStale
                      ? Icons.history_toggle_off_rounded
                      : Icons.cloud_done_rounded,
                  color: iconColor,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: TextStyle(
                          fontWeight: FontWeight.w800,
                          color: iconColor,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        lastSyncLabel,
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                MobileInfoChip(text: '$pendingCount pending'),
                if (retryNeededCount > 0)
                  MobileInfoChip(text: '$retryNeededCount retry needed'),
                if (manualReviewCount > 0)
                  MobileInfoChip(text: '$manualReviewCount manual review'),
                if (longPendingCount > 0)
                  MobileInfoChip(
                    text: '$longPendingCount matagal nang pending',
                  ),
              ],
            ),
            if (errorMessage != null && errorMessage!.trim().isNotEmpty) ...[
              const SizedBox(height: 10),
              Text(
                'Huling sync issue: $errorMessage',
                style: TextStyle(
                  color: Colors.red.shade700,
                  fontSize: 12,
                  height: 1.35,
                ),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class MobilePendingActionsCard extends StatelessWidget {
  const MobilePendingActionsCard({
    super.key,
    required this.actions,
    this.onSyncNow,
    this.onRetryAction,
    this.onDismissAction,
    this.busyActionId,
  });

  final List<MobileQueuedAction> actions;
  final VoidCallback? onSyncNow;
  final void Function(MobileQueuedAction action)? onRetryAction;
  final void Function(MobileQueuedAction action)? onDismissAction;
  final String? busyActionId;

  String _formatAge(DateTime timestamp) {
    final age = DateTime.now().difference(timestamp);

    if (age.inMinutes < 1) {
      return 'ngayon lang';
    }

    if (age.inMinutes < 60) {
      return '${age.inMinutes} min ang nakalipas';
    }

    if (age.inHours < 24) {
      return '${age.inHours} oras ang nakalipas';
    }

    return '${age.inDays} araw ang nakalipas';
  }

  @override
  Widget build(BuildContext context) {
    if (actions.isEmpty) {
      return const SizedBox.shrink();
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Icon(
                  Icons.pending_actions_rounded,
                  color: Color(0xFF92400E),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Pending Mobile Actions',
                        style: TextStyle(fontWeight: FontWeight.w800),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Ito ang mga aksyong naka-save sa device at kailangang ma-sync o mano-manong i-review.',
                        style: TextStyle(color: Colors.grey.shade700),
                      ),
                    ],
                  ),
                ),
                if (onSyncNow != null)
                  OutlinedButton.icon(
                    onPressed: onSyncNow,
                    icon: const Icon(Icons.sync_rounded),
                    label: const Text('Sync now'),
                  ),
              ],
            ),
            const SizedBox(height: 14),
            ...actions.take(5).map((action) {
              final busy = busyActionId == action.id;
              return Container(
                width: double.infinity,
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFFF8FAFC),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFFE2E8F0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          child: Text(
                            action.typeLabel,
                            style: const TextStyle(fontWeight: FontWeight.w700),
                          ),
                        ),
                        Text(
                          _formatAge(action.createdAt),
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey.shade600,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        MobileInfoChip(text: 'attempts: ${action.attempts}'),
                        if (action.hasError)
                          MobileInfoChip(
                            text: action.hasConflict
                                ? 'stale data'
                                : 'retry needed',
                          ),
                        if (action.needsManualReview)
                          const MobileInfoChip(text: 'manual review'),
                        if (action.isLongPending)
                          const MobileInfoChip(text: 'matagal nang pending'),
                      ],
                    ),
                    if (action.hasConflict &&
                        action.conflictSummary != null &&
                        action.conflictSummary!.trim().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        action.conflictSummary!,
                        style: TextStyle(
                          color: Colors.amber.shade900,
                          fontSize: 12,
                          height: 1.35,
                        ),
                      ),
                      if (action.recommendedAction != null &&
                          action.recommendedAction!.trim().isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          'Gawin: ${action.recommendedAction!}',
                          style: TextStyle(
                            color: Colors.grey.shade700,
                            fontSize: 12,
                            height: 1.35,
                          ),
                        ),
                      ],
                    ] else if (action.lastError != null &&
                        action.lastError!.trim().isNotEmpty) ...[
                      const SizedBox(height: 8),
                      Text(
                        action.lastError!,
                        style: TextStyle(
                          color: Colors.red.shade700,
                          fontSize: 12,
                          height: 1.35,
                        ),
                      ),
                    ],
                    const SizedBox(height: 10),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        if (onRetryAction != null && !action.hasConflict)
                          OutlinedButton.icon(
                            onPressed: busy
                                ? null
                                : () => onRetryAction!(action),
                            icon: busy
                                ? const SizedBox(
                                    width: 14,
                                    height: 14,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 2,
                                    ),
                                  )
                                : const Icon(Icons.refresh_rounded),
                            label: Text(busy ? 'Nireretry...' : 'Retry now'),
                          ),
                        if (onDismissAction != null)
                          OutlinedButton.icon(
                            onPressed: busy
                                ? null
                                : () => onDismissAction!(action),
                            icon: const Icon(Icons.close_rounded),
                            label: const Text('Dismiss'),
                          ),
                      ],
                    ),
                  ],
                ),
              );
            }),
            if (actions.length > 5)
              Text(
                '+${actions.length - 5} pang pending action ang nasa queue.',
                style: TextStyle(fontSize: 12, color: Colors.grey.shade600),
              ),
          ],
        ),
      ),
    );
  }
}
